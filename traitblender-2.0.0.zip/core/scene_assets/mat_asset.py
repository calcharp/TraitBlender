from .scene_asset import SceneAsset

class MatAsset(SceneAsset):
    """
    Specialized SceneAsset for managing mat objects in Blender.
    """
    pass 