"""
TraitBlender Scene Assets

Scene asset management system for Blender objects with enhanced transformation capabilities.
"""

__all__ = [
] 