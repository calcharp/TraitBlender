from .scene_asset import SceneAsset

class TableAsset(SceneAsset):
    """
    Specialized SceneAsset for managing table objects in Blender.
    """
    pass 