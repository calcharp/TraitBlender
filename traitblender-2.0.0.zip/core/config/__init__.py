# TraitBlender Config Module
# Configuration management for TraitBlender 