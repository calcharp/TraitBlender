"""
TraitBlender Transforms Module

Transform factory system for morphological operations.
"""

TRANSFORMS = {}

__all__ = [
    "TRANSFORMS",
] 